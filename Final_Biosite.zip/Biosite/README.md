<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>

  <h1>CSD 340 Web Development with HTML and CSS</h1>
  <h2>Contributors</h2>
 <ul>
    <li> Joseph Issa </li>
    <li> Colby King </li>
  </ul>

</body>
</html>